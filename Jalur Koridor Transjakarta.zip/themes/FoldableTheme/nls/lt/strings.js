define({
  "_themeLabel": "Langų tema",
  "_layout_default": "Numatytasis maketas",
  "_layout_layout1": "1 maketas"
});