define({
  "_themeLabel": "Taitettava teema",
  "_layout_default": "Oletusasettelu",
  "_layout_layout1": "Asettelu 1"
});