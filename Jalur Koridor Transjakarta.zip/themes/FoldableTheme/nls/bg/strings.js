define({
  "_themeLabel": "Сгъваема тема",
  "_layout_default": "Оформление по подразбиране",
  "_layout_layout1": "Оформление 1"
});